﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_2_task_3
{
    internal class Class1
    {
        public static ArrayList userName = new ArrayList();
        public static ArrayList PassWord = new ArrayList();
        public static int count;
    }
}
