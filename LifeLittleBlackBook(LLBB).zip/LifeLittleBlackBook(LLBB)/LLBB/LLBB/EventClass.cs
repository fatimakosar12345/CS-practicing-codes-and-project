﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LLBB
{
    internal class EventClass
    {
        public static ArrayList category = new ArrayList();
        public static ArrayList dayno = new ArrayList();
        public static ArrayList monthno = new ArrayList();
        public static ArrayList year = new ArrayList();
        public static ArrayList time = new ArrayList();
        public static int count;
    }
}
