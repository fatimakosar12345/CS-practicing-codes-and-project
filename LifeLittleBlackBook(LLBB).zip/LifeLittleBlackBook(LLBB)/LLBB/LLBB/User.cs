﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LLBB
{
    internal class User
    {
        public static ArrayList userID = new ArrayList();
        public static ArrayList userName = new ArrayList();
        public static ArrayList PassWord = new ArrayList();
        public static int count;
    }
}
