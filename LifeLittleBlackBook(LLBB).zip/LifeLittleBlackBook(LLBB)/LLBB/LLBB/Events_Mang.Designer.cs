﻿namespace LLBB
{
    partial class Events_Mang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.Addbtn = new System.Windows.Forms.Button();
            this.panel43 = new System.Windows.Forms.Panel();
            this.timetxt = new System.Windows.Forms.TextBox();
            this.yeartxt = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.monNotxt = new System.Windows.Forms.TextBox();
            this.dayNotxt = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.displaybtn = new System.Windows.Forms.Button();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.Editbtn = new System.Windows.Forms.Button();
            this.Rmvbtn = new System.Windows.Forms.Button();
            this.link = new System.Windows.Forms.LinkLabel();
            this.catgrytxt = new System.Windows.Forms.TextBox();
            this.panel43.SuspendLayout();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Teal;
            this.label4.Location = new System.Drawing.Point(48, 38);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(262, 31);
            this.label4.TabIndex = 14;
            this.label4.Text = "Events Management";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // Addbtn
            // 
            this.Addbtn.BackColor = System.Drawing.Color.Transparent;
            this.Addbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addbtn.ForeColor = System.Drawing.Color.Teal;
            this.Addbtn.Location = new System.Drawing.Point(328, 86);
            this.Addbtn.Name = "Addbtn";
            this.Addbtn.Size = new System.Drawing.Size(209, 58);
            this.Addbtn.TabIndex = 18;
            this.Addbtn.Text = "Add Event";
            this.Addbtn.UseVisualStyleBackColor = false;
            this.Addbtn.Click += new System.EventHandler(this.Addbtn_Click);
            // 
            // panel43
            // 
            this.panel43.BackColor = System.Drawing.Color.PowderBlue;
            this.panel43.Controls.Add(this.timetxt);
            this.panel43.Controls.Add(this.yeartxt);
            this.panel43.Controls.Add(this.label19);
            this.panel43.Controls.Add(this.label20);
            this.panel43.Controls.Add(this.monNotxt);
            this.panel43.Controls.Add(this.dayNotxt);
            this.panel43.Controls.Add(this.label17);
            this.panel43.Controls.Add(this.label18);
            this.panel43.Controls.Add(this.catgrytxt);
            this.panel43.Controls.Add(this.label16);
            this.panel43.Location = new System.Drawing.Point(29, 131);
            this.panel43.Name = "panel43";
            this.panel43.Size = new System.Drawing.Size(256, 331);
            this.panel43.TabIndex = 23;
            // 
            // timetxt
            // 
            this.timetxt.BackColor = System.Drawing.Color.WhiteSmoke;
            this.timetxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.timetxt.ForeColor = System.Drawing.Color.Teal;
            this.timetxt.Location = new System.Drawing.Point(106, 274);
            this.timetxt.Name = "timetxt";
            this.timetxt.Size = new System.Drawing.Size(120, 24);
            this.timetxt.TabIndex = 11;
            // 
            // yeartxt
            // 
            this.yeartxt.BackColor = System.Drawing.Color.WhiteSmoke;
            this.yeartxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yeartxt.ForeColor = System.Drawing.Color.Teal;
            this.yeartxt.Location = new System.Drawing.Point(106, 215);
            this.yeartxt.Name = "yeartxt";
            this.yeartxt.Size = new System.Drawing.Size(120, 24);
            this.yeartxt.TabIndex = 10;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Teal;
            this.label19.Location = new System.Drawing.Point(22, 218);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(38, 18);
            this.label19.TabIndex = 8;
            this.label19.Text = "Year";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Teal;
            this.label20.Location = new System.Drawing.Point(22, 277);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(41, 18);
            this.label20.TabIndex = 9;
            this.label20.Text = "Time";
            // 
            // monNotxt
            // 
            this.monNotxt.BackColor = System.Drawing.Color.WhiteSmoke;
            this.monNotxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.monNotxt.ForeColor = System.Drawing.Color.Teal;
            this.monNotxt.Location = new System.Drawing.Point(106, 155);
            this.monNotxt.Name = "monNotxt";
            this.monNotxt.Size = new System.Drawing.Size(120, 24);
            this.monNotxt.TabIndex = 7;
            // 
            // dayNotxt
            // 
            this.dayNotxt.BackColor = System.Drawing.Color.WhiteSmoke;
            this.dayNotxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dayNotxt.ForeColor = System.Drawing.Color.Teal;
            this.dayNotxt.Location = new System.Drawing.Point(106, 94);
            this.dayNotxt.Name = "dayNotxt";
            this.dayNotxt.Size = new System.Drawing.Size(120, 24);
            this.dayNotxt.TabIndex = 6;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Teal;
            this.label17.Location = new System.Drawing.Point(22, 97);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(62, 18);
            this.label17.TabIndex = 4;
            this.label17.Text = "Day_No";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Teal;
            this.label18.Location = new System.Drawing.Point(22, 158);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(78, 18);
            this.label18.TabIndex = 5;
            this.label18.Text = "Month_No";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Teal;
            this.label16.Location = new System.Drawing.Point(22, 38);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(68, 18);
            this.label16.TabIndex = 1;
            this.label16.Text = "Category";
            // 
            // displaybtn
            // 
            this.displaybtn.BackColor = System.Drawing.Color.Transparent;
            this.displaybtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displaybtn.ForeColor = System.Drawing.Color.Teal;
            this.displaybtn.Location = new System.Drawing.Point(568, 183);
            this.displaybtn.Name = "displaybtn";
            this.displaybtn.Size = new System.Drawing.Size(209, 58);
            this.displaybtn.TabIndex = 24;
            this.displaybtn.Text = "Display Calender";
            this.displaybtn.UseVisualStyleBackColor = false;
            this.displaybtn.Click += new System.EventHandler(this.displaybtn_Click);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.BackColor = System.Drawing.Color.Transparent;
            this.linkLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.ForeColor = System.Drawing.Color.Teal;
            this.linkLabel1.LinkArea = new System.Windows.Forms.LinkArea(0, 1);
            this.linkLabel1.LinkColor = System.Drawing.Color.Teal;
            this.linkLabel1.Location = new System.Drawing.Point(12, 36);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(32, 33);
            this.linkLabel1.TabIndex = 25;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "<";
            this.linkLabel1.VisitedLinkColor = System.Drawing.Color.Transparent;
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // Editbtn
            // 
            this.Editbtn.BackColor = System.Drawing.Color.Transparent;
            this.Editbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Editbtn.ForeColor = System.Drawing.Color.Teal;
            this.Editbtn.Location = new System.Drawing.Point(568, 86);
            this.Editbtn.Name = "Editbtn";
            this.Editbtn.Size = new System.Drawing.Size(209, 58);
            this.Editbtn.TabIndex = 20;
            this.Editbtn.Text = "Edit Event";
            this.Editbtn.UseVisualStyleBackColor = false;
            this.Editbtn.Click += new System.EventHandler(this.Editbtn_Click);
            // 
            // Rmvbtn
            // 
            this.Rmvbtn.BackColor = System.Drawing.Color.Transparent;
            this.Rmvbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Rmvbtn.ForeColor = System.Drawing.Color.Teal;
            this.Rmvbtn.Location = new System.Drawing.Point(328, 183);
            this.Rmvbtn.Name = "Rmvbtn";
            this.Rmvbtn.Size = new System.Drawing.Size(209, 58);
            this.Rmvbtn.TabIndex = 19;
            this.Rmvbtn.Text = "Remove Event";
            this.Rmvbtn.UseVisualStyleBackColor = false;
            this.Rmvbtn.Click += new System.EventHandler(this.Rmvbtn_Click);
            // 
            // link
            // 
            this.link.AutoSize = true;
            this.link.BackColor = System.Drawing.Color.Transparent;
            this.link.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.link.LinkColor = System.Drawing.Color.Teal;
            this.link.Location = new System.Drawing.Point(698, 26);
            this.link.Name = "link";
            this.link.Size = new System.Drawing.Size(104, 16);
            this.link.TabIndex = 26;
            this.link.TabStop = true;
            this.link.Text = "Back to Home";
            this.link.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.link_LinkClicked);
            // 
            // catgrytxt
            // 
            this.catgrytxt.BackColor = System.Drawing.Color.WhiteSmoke;
            this.catgrytxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.catgrytxt.ForeColor = System.Drawing.Color.Teal;
            this.catgrytxt.Location = new System.Drawing.Point(106, 35);
            this.catgrytxt.Name = "catgrytxt";
            this.catgrytxt.Size = new System.Drawing.Size(120, 24);
            this.catgrytxt.TabIndex = 3;
            // 
            // Events_Mang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.BackgroundImage = global::LLBB.Properties.Resources.cal__2_;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(826, 537);
            this.Controls.Add(this.link);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.displaybtn);
            this.Controls.Add(this.panel43);
            this.Controls.Add(this.Editbtn);
            this.Controls.Add(this.Rmvbtn);
            this.Controls.Add(this.Addbtn);
            this.Controls.Add(this.label4);
            this.Name = "Events_Mang";
            this.Text = "Events_Mang";
            this.Load += new System.EventHandler(this.Events_Load);
            this.panel43.ResumeLayout(false);
            this.panel43.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button Addbtn;
        private System.Windows.Forms.Panel panel43;
        private System.Windows.Forms.TextBox timetxt;
        private System.Windows.Forms.TextBox yeartxt;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox monNotxt;
        private System.Windows.Forms.TextBox dayNotxt;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button displaybtn;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Button Editbtn;
        private System.Windows.Forms.Button Rmvbtn;
        private System.Windows.Forms.LinkLabel link;
        private System.Windows.Forms.TextBox catgrytxt;
    }
}