﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LLBB
{
    internal class NotesClass
    {
        public static ArrayList Date = new ArrayList();
        public static ArrayList Day = new ArrayList();
        public static ArrayList Note = new ArrayList();
        public static int count;
    }
}
