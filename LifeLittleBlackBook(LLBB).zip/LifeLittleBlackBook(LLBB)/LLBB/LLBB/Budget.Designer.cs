﻿namespace LLBB
{
    partial class Budget
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel3 = new System.Windows.Forms.Panel();
            this.RemainIncm = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.Addbtn = new System.Windows.Forms.Button();
            this.date = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.Misc = new System.Windows.Forms.TextBox();
            this.Medical = new System.Windows.Forms.TextBox();
            this.Internet = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.Education = new System.Windows.Forms.TextBox();
            this.Food = new System.Windows.Forms.TextBox();
            this.Bill = new System.Windows.Forms.TextBox();
            this.NetIncm = new System.Windows.Forms.TextBox();
            this.SrcOfIncm = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Editbtn = new System.Windows.Forms.Button();
            this.Delbtn = new System.Windows.Forms.Button();
            this.panel = new System.Windows.Forms.Panel();
            this.Textlabel = new System.Windows.Forms.Label();
            this.datetxt = new System.Windows.Forms.RichTextBox();
            this.remaintxt = new System.Windows.Forms.RichTextBox();
            this.misctxt = new System.Windows.Forms.RichTextBox();
            this.edutxt = new System.Windows.Forms.RichTextBox();
            this.Inttxt = new System.Windows.Forms.RichTextBox();
            this.foodtxt = new System.Windows.Forms.RichTextBox();
            this.medtxt = new System.Windows.Forms.RichTextBox();
            this.nettxt = new System.Windows.Forms.RichTextBox();
            this.billtxt = new System.Windows.Forms.RichTextBox();
            this.srctxt = new System.Windows.Forms.RichTextBox();
            this.Nextbtn = new System.Windows.Forms.Button();
            this.Prevbtn = new System.Windows.Forms.Button();
            this.Remainlabel = new System.Windows.Forms.Label();
            this.edulabel = new System.Windows.Forms.Label();
            this.datelabel = new System.Windows.Forms.Label();
            this.misclabel = new System.Windows.Forms.Label();
            this.foodlabel = new System.Windows.Forms.Label();
            this.billlabel = new System.Windows.Forms.Label();
            this.medlabel = new System.Windows.Forms.Label();
            this.srclabel = new System.Windows.Forms.Label();
            this.Intlabel = new System.Windows.Forms.Label();
            this.netlabel = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.link = new System.Windows.Forms.LinkLabel();
            this.panel3.SuspendLayout();
            this.panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.panel3.Controls.Add(this.RemainIncm);
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.Addbtn);
            this.panel3.Controls.Add(this.date);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.Misc);
            this.panel3.Controls.Add(this.Medical);
            this.panel3.Controls.Add(this.Internet);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.Education);
            this.panel3.Controls.Add(this.Food);
            this.panel3.Controls.Add(this.Bill);
            this.panel3.Controls.Add(this.NetIncm);
            this.panel3.Controls.Add(this.SrcOfIncm);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.label2);
            this.panel3.ForeColor = System.Drawing.Color.Teal;
            this.panel3.Location = new System.Drawing.Point(624, 100);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(412, 599);
            this.panel3.TabIndex = 5;
            // 
            // RemainIncm
            // 
            this.RemainIncm.BackColor = System.Drawing.Color.WhiteSmoke;
            this.RemainIncm.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RemainIncm.ForeColor = System.Drawing.Color.Teal;
            this.RemainIncm.Location = new System.Drawing.Point(237, 428);
            this.RemainIncm.Name = "RemainIncm";
            this.RemainIncm.Size = new System.Drawing.Size(136, 24);
            this.RemainIncm.TabIndex = 20;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Teal;
            this.label12.Location = new System.Drawing.Point(44, 431);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(131, 18);
            this.label12.TabIndex = 19;
            this.label12.Text = "Remaining Income";
            // 
            // Addbtn
            // 
            this.Addbtn.BackColor = System.Drawing.Color.Transparent;
            this.Addbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addbtn.ForeColor = System.Drawing.Color.Teal;
            this.Addbtn.Location = new System.Drawing.Point(57, 528);
            this.Addbtn.Name = "Addbtn";
            this.Addbtn.Size = new System.Drawing.Size(306, 46);
            this.Addbtn.TabIndex = 1;
            this.Addbtn.Text = "Add";
            this.Addbtn.UseVisualStyleBackColor = false;
            this.Addbtn.Click += new System.EventHandler(this.Addbtn_Click);
            // 
            // date
            // 
            this.date.BackColor = System.Drawing.Color.WhiteSmoke;
            this.date.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.date.ForeColor = System.Drawing.Color.Teal;
            this.date.Location = new System.Drawing.Point(237, 478);
            this.date.Name = "date";
            this.date.Size = new System.Drawing.Size(136, 24);
            this.date.TabIndex = 17;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Teal;
            this.label7.Location = new System.Drawing.Point(44, 331);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(143, 18);
            this.label7.TabIndex = 11;
            this.label7.Text = "Education Expenses";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Teal;
            this.label10.Location = new System.Drawing.Point(44, 481);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(39, 18);
            this.label10.TabIndex = 15;
            this.label10.Text = "Date";
            // 
            // Misc
            // 
            this.Misc.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Misc.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Misc.ForeColor = System.Drawing.Color.Teal;
            this.Misc.Location = new System.Drawing.Point(237, 379);
            this.Misc.Name = "Misc";
            this.Misc.Size = new System.Drawing.Size(136, 24);
            this.Misc.TabIndex = 18;
            // 
            // Medical
            // 
            this.Medical.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Medical.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Medical.ForeColor = System.Drawing.Color.Teal;
            this.Medical.Location = new System.Drawing.Point(237, 180);
            this.Medical.Name = "Medical";
            this.Medical.Size = new System.Drawing.Size(136, 24);
            this.Medical.TabIndex = 0;
            // 
            // Internet
            // 
            this.Internet.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Internet.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Internet.ForeColor = System.Drawing.Color.Teal;
            this.Internet.Location = new System.Drawing.Point(237, 277);
            this.Internet.Name = "Internet";
            this.Internet.Size = new System.Drawing.Size(136, 24);
            this.Internet.TabIndex = 10;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Teal;
            this.label9.Location = new System.Drawing.Point(44, 382);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(172, 18);
            this.label9.TabIndex = 14;
            this.label9.Text = "Miscellaneous Expenses";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Teal;
            this.label8.Location = new System.Drawing.Point(44, 232);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(112, 18);
            this.label8.TabIndex = 13;
            this.label8.Text = "Food Expenses";
            // 
            // Education
            // 
            this.Education.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Education.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Education.ForeColor = System.Drawing.Color.Teal;
            this.Education.Location = new System.Drawing.Point(237, 328);
            this.Education.Name = "Education";
            this.Education.Size = new System.Drawing.Size(136, 24);
            this.Education.TabIndex = 12;
            // 
            // Food
            // 
            this.Food.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Food.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Food.ForeColor = System.Drawing.Color.Teal;
            this.Food.Location = new System.Drawing.Point(237, 229);
            this.Food.Name = "Food";
            this.Food.Size = new System.Drawing.Size(136, 24);
            this.Food.TabIndex = 16;
            // 
            // Bill
            // 
            this.Bill.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Bill.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bill.ForeColor = System.Drawing.Color.Teal;
            this.Bill.Location = new System.Drawing.Point(237, 131);
            this.Bill.Name = "Bill";
            this.Bill.Size = new System.Drawing.Size(136, 24);
            this.Bill.TabIndex = 9;
            // 
            // NetIncm
            // 
            this.NetIncm.BackColor = System.Drawing.Color.WhiteSmoke;
            this.NetIncm.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NetIncm.ForeColor = System.Drawing.Color.Teal;
            this.NetIncm.Location = new System.Drawing.Point(237, 80);
            this.NetIncm.Name = "NetIncm";
            this.NetIncm.Size = new System.Drawing.Size(136, 24);
            this.NetIncm.TabIndex = 8;
            // 
            // SrcOfIncm
            // 
            this.SrcOfIncm.BackColor = System.Drawing.Color.WhiteSmoke;
            this.SrcOfIncm.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SrcOfIncm.ForeColor = System.Drawing.Color.Teal;
            this.SrcOfIncm.Location = new System.Drawing.Point(237, 32);
            this.SrcOfIncm.Name = "SrcOfIncm";
            this.SrcOfIncm.Size = new System.Drawing.Size(136, 24);
            this.SrcOfIncm.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Teal;
            this.label6.Location = new System.Drawing.Point(44, 183);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(128, 18);
            this.label6.TabIndex = 5;
            this.label6.Text = "Medical Expenses";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Teal;
            this.label5.Location = new System.Drawing.Point(44, 280);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(125, 18);
            this.label5.TabIndex = 4;
            this.label5.Text = "Internet Expenses";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Teal;
            this.label4.Location = new System.Drawing.Point(44, 134);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 18);
            this.label4.TabIndex = 3;
            this.label4.Text = "Bill Expenses";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Teal;
            this.label3.Location = new System.Drawing.Point(44, 83);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 18);
            this.label3.TabIndex = 2;
            this.label3.Text = "Net Income";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Teal;
            this.label2.Location = new System.Drawing.Point(44, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(126, 18);
            this.label2.TabIndex = 1;
            this.label2.Text = "Source of Income";
            // 
            // Editbtn
            // 
            this.Editbtn.BackColor = System.Drawing.Color.Transparent;
            this.Editbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Editbtn.ForeColor = System.Drawing.Color.Teal;
            this.Editbtn.Location = new System.Drawing.Point(397, 663);
            this.Editbtn.Name = "Editbtn";
            this.Editbtn.Size = new System.Drawing.Size(171, 46);
            this.Editbtn.TabIndex = 3;
            this.Editbtn.Text = "Edit";
            this.Editbtn.UseVisualStyleBackColor = false;
            this.Editbtn.Click += new System.EventHandler(this.Editbtn_Click);
            // 
            // Delbtn
            // 
            this.Delbtn.BackColor = System.Drawing.Color.Transparent;
            this.Delbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Delbtn.ForeColor = System.Drawing.Color.Teal;
            this.Delbtn.Location = new System.Drawing.Point(209, 663);
            this.Delbtn.Name = "Delbtn";
            this.Delbtn.Size = new System.Drawing.Size(172, 46);
            this.Delbtn.TabIndex = 2;
            this.Delbtn.Text = "Delete";
            this.Delbtn.UseVisualStyleBackColor = false;
            this.Delbtn.Click += new System.EventHandler(this.Delbtn_Click);
            // 
            // panel
            // 
            this.panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.panel.Controls.Add(this.Textlabel);
            this.panel.Controls.Add(this.datetxt);
            this.panel.Controls.Add(this.remaintxt);
            this.panel.Controls.Add(this.misctxt);
            this.panel.Controls.Add(this.edutxt);
            this.panel.Controls.Add(this.Inttxt);
            this.panel.Controls.Add(this.foodtxt);
            this.panel.Controls.Add(this.medtxt);
            this.panel.Controls.Add(this.nettxt);
            this.panel.Controls.Add(this.billtxt);
            this.panel.Controls.Add(this.srctxt);
            this.panel.Controls.Add(this.Nextbtn);
            this.panel.Controls.Add(this.Prevbtn);
            this.panel.Controls.Add(this.Remainlabel);
            this.panel.Controls.Add(this.Editbtn);
            this.panel.Controls.Add(this.edulabel);
            this.panel.Controls.Add(this.Delbtn);
            this.panel.Controls.Add(this.datelabel);
            this.panel.Controls.Add(this.misclabel);
            this.panel.Controls.Add(this.foodlabel);
            this.panel.Controls.Add(this.billlabel);
            this.panel.Controls.Add(this.medlabel);
            this.panel.Controls.Add(this.srclabel);
            this.panel.Controls.Add(this.Intlabel);
            this.panel.Controls.Add(this.netlabel);
            this.panel.Location = new System.Drawing.Point(12, 12);
            this.panel.Name = "panel";
            this.panel.Size = new System.Drawing.Size(586, 725);
            this.panel.TabIndex = 11;
            this.panel.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // Textlabel
            // 
            this.Textlabel.AutoSize = true;
            this.Textlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textlabel.ForeColor = System.Drawing.Color.Teal;
            this.Textlabel.Location = new System.Drawing.Point(166, 332);
            this.Textlabel.Name = "Textlabel";
            this.Textlabel.Size = new System.Drawing.Size(0, 31);
            this.Textlabel.TabIndex = 21;
            // 
            // datetxt
            // 
            this.datetxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.datetxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.datetxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datetxt.ForeColor = System.Drawing.Color.Teal;
            this.datetxt.Location = new System.Drawing.Point(283, 614);
            this.datetxt.Name = "datetxt";
            this.datetxt.Size = new System.Drawing.Size(222, 47);
            this.datetxt.TabIndex = 43;
            this.datetxt.Text = "";
            // 
            // remaintxt
            // 
            this.remaintxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.remaintxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.remaintxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.remaintxt.ForeColor = System.Drawing.Color.Teal;
            this.remaintxt.Location = new System.Drawing.Point(283, 548);
            this.remaintxt.Name = "remaintxt";
            this.remaintxt.Size = new System.Drawing.Size(222, 47);
            this.remaintxt.TabIndex = 42;
            this.remaintxt.Text = "";
            // 
            // misctxt
            // 
            this.misctxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.misctxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.misctxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.misctxt.ForeColor = System.Drawing.Color.Teal;
            this.misctxt.Location = new System.Drawing.Point(283, 482);
            this.misctxt.Name = "misctxt";
            this.misctxt.Size = new System.Drawing.Size(222, 47);
            this.misctxt.TabIndex = 41;
            this.misctxt.Text = "";
            // 
            // edutxt
            // 
            this.edutxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.edutxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.edutxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.edutxt.ForeColor = System.Drawing.Color.Teal;
            this.edutxt.Location = new System.Drawing.Point(283, 417);
            this.edutxt.Name = "edutxt";
            this.edutxt.Size = new System.Drawing.Size(222, 47);
            this.edutxt.TabIndex = 40;
            this.edutxt.Text = "";
            // 
            // Inttxt
            // 
            this.Inttxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.Inttxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Inttxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Inttxt.ForeColor = System.Drawing.Color.Teal;
            this.Inttxt.Location = new System.Drawing.Point(283, 351);
            this.Inttxt.Name = "Inttxt";
            this.Inttxt.Size = new System.Drawing.Size(222, 47);
            this.Inttxt.TabIndex = 39;
            this.Inttxt.Text = "";
            // 
            // foodtxt
            // 
            this.foodtxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.foodtxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.foodtxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.foodtxt.ForeColor = System.Drawing.Color.Teal;
            this.foodtxt.Location = new System.Drawing.Point(283, 286);
            this.foodtxt.Name = "foodtxt";
            this.foodtxt.Size = new System.Drawing.Size(222, 47);
            this.foodtxt.TabIndex = 38;
            this.foodtxt.Text = "";
            // 
            // medtxt
            // 
            this.medtxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.medtxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.medtxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.medtxt.ForeColor = System.Drawing.Color.Teal;
            this.medtxt.Location = new System.Drawing.Point(283, 223);
            this.medtxt.Name = "medtxt";
            this.medtxt.Size = new System.Drawing.Size(222, 47);
            this.medtxt.TabIndex = 37;
            this.medtxt.Text = "";
            this.medtxt.TextChanged += new System.EventHandler(this.richTextBox3_TextChanged);
            // 
            // nettxt
            // 
            this.nettxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.nettxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.nettxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nettxt.ForeColor = System.Drawing.Color.Teal;
            this.nettxt.Location = new System.Drawing.Point(283, 98);
            this.nettxt.Name = "nettxt";
            this.nettxt.Size = new System.Drawing.Size(222, 47);
            this.nettxt.TabIndex = 36;
            this.nettxt.Text = "";
            // 
            // billtxt
            // 
            this.billtxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.billtxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.billtxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.billtxt.ForeColor = System.Drawing.Color.Teal;
            this.billtxt.Location = new System.Drawing.Point(283, 157);
            this.billtxt.Name = "billtxt";
            this.billtxt.Size = new System.Drawing.Size(222, 47);
            this.billtxt.TabIndex = 35;
            this.billtxt.Text = "";
            // 
            // srctxt
            // 
            this.srctxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.srctxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.srctxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.srctxt.ForeColor = System.Drawing.Color.Teal;
            this.srctxt.Location = new System.Drawing.Point(283, 39);
            this.srctxt.Name = "srctxt";
            this.srctxt.Size = new System.Drawing.Size(222, 47);
            this.srctxt.TabIndex = 34;
            this.srctxt.Text = "";
            // 
            // Nextbtn
            // 
            this.Nextbtn.BackColor = System.Drawing.Color.Transparent;
            this.Nextbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nextbtn.Location = new System.Drawing.Point(529, 324);
            this.Nextbtn.Name = "Nextbtn";
            this.Nextbtn.Size = new System.Drawing.Size(57, 47);
            this.Nextbtn.TabIndex = 32;
            this.Nextbtn.Text = ">";
            this.Nextbtn.UseVisualStyleBackColor = false;
            this.Nextbtn.Click += new System.EventHandler(this.Nextbtn_Click);
            // 
            // Prevbtn
            // 
            this.Prevbtn.BackColor = System.Drawing.Color.Transparent;
            this.Prevbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Prevbtn.Location = new System.Drawing.Point(0, 324);
            this.Prevbtn.Name = "Prevbtn";
            this.Prevbtn.Size = new System.Drawing.Size(57, 47);
            this.Prevbtn.TabIndex = 31;
            this.Prevbtn.Text = "<";
            this.Prevbtn.UseVisualStyleBackColor = false;
            this.Prevbtn.Click += new System.EventHandler(this.Prevbtn_Click);
            // 
            // Remainlabel
            // 
            this.Remainlabel.AutoSize = true;
            this.Remainlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Remainlabel.ForeColor = System.Drawing.Color.Teal;
            this.Remainlabel.Location = new System.Drawing.Point(90, 548);
            this.Remainlabel.Name = "Remainlabel";
            this.Remainlabel.Size = new System.Drawing.Size(131, 18);
            this.Remainlabel.TabIndex = 30;
            this.Remainlabel.Text = "Remaining Income";
            // 
            // edulabel
            // 
            this.edulabel.AutoSize = true;
            this.edulabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.edulabel.ForeColor = System.Drawing.Color.Teal;
            this.edulabel.Location = new System.Drawing.Point(90, 417);
            this.edulabel.Name = "edulabel";
            this.edulabel.Size = new System.Drawing.Size(143, 18);
            this.edulabel.TabIndex = 26;
            this.edulabel.Text = "Education Expenses";
            // 
            // datelabel
            // 
            this.datelabel.AutoSize = true;
            this.datelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datelabel.ForeColor = System.Drawing.Color.Teal;
            this.datelabel.Location = new System.Drawing.Point(90, 614);
            this.datelabel.Name = "datelabel";
            this.datelabel.Size = new System.Drawing.Size(39, 18);
            this.datelabel.TabIndex = 29;
            this.datelabel.Text = "Date";
            // 
            // misclabel
            // 
            this.misclabel.AutoSize = true;
            this.misclabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.misclabel.ForeColor = System.Drawing.Color.Teal;
            this.misclabel.Location = new System.Drawing.Point(90, 482);
            this.misclabel.Name = "misclabel";
            this.misclabel.Size = new System.Drawing.Size(172, 18);
            this.misclabel.TabIndex = 28;
            this.misclabel.Text = "Miscellaneous Expenses";
            // 
            // foodlabel
            // 
            this.foodlabel.AutoSize = true;
            this.foodlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.foodlabel.ForeColor = System.Drawing.Color.Teal;
            this.foodlabel.Location = new System.Drawing.Point(90, 286);
            this.foodlabel.Name = "foodlabel";
            this.foodlabel.Size = new System.Drawing.Size(112, 18);
            this.foodlabel.TabIndex = 27;
            this.foodlabel.Text = "Food Expenses";
            // 
            // billlabel
            // 
            this.billlabel.AutoSize = true;
            this.billlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.billlabel.ForeColor = System.Drawing.Color.Teal;
            this.billlabel.Location = new System.Drawing.Point(90, 157);
            this.billlabel.Name = "billlabel";
            this.billlabel.Size = new System.Drawing.Size(96, 18);
            this.billlabel.TabIndex = 23;
            this.billlabel.Text = "Bill Expenses";
            // 
            // medlabel
            // 
            this.medlabel.AutoSize = true;
            this.medlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.medlabel.ForeColor = System.Drawing.Color.Teal;
            this.medlabel.Location = new System.Drawing.Point(90, 223);
            this.medlabel.Name = "medlabel";
            this.medlabel.Size = new System.Drawing.Size(128, 18);
            this.medlabel.TabIndex = 25;
            this.medlabel.Text = "Medical Expenses";
            // 
            // srclabel
            // 
            this.srclabel.AutoSize = true;
            this.srclabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.srclabel.ForeColor = System.Drawing.Color.Teal;
            this.srclabel.Location = new System.Drawing.Point(90, 39);
            this.srclabel.Name = "srclabel";
            this.srclabel.Size = new System.Drawing.Size(126, 18);
            this.srclabel.TabIndex = 21;
            this.srclabel.Text = "Source of Income";
            // 
            // Intlabel
            // 
            this.Intlabel.AutoSize = true;
            this.Intlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Intlabel.ForeColor = System.Drawing.Color.Teal;
            this.Intlabel.Location = new System.Drawing.Point(90, 351);
            this.Intlabel.Name = "Intlabel";
            this.Intlabel.Size = new System.Drawing.Size(125, 18);
            this.Intlabel.TabIndex = 24;
            this.Intlabel.Text = "Internet Expenses";
            // 
            // netlabel
            // 
            this.netlabel.AutoSize = true;
            this.netlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.netlabel.ForeColor = System.Drawing.Color.Teal;
            this.netlabel.Location = new System.Drawing.Point(90, 100);
            this.netlabel.Name = "netlabel";
            this.netlabel.Size = new System.Drawing.Size(84, 18);
            this.netlabel.TabIndex = 22;
            this.netlabel.Text = "Net Income";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Teal;
            this.label11.Location = new System.Drawing.Point(802, 39);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(106, 33);
            this.label11.TabIndex = 21;
            this.label11.Text = "Budget";
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.BackColor = System.Drawing.Color.Transparent;
            this.linkLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.ForeColor = System.Drawing.Color.Teal;
            this.linkLabel1.LinkArea = new System.Windows.Forms.LinkArea(0, 1);
            this.linkLabel1.LinkColor = System.Drawing.Color.Teal;
            this.linkLabel1.Location = new System.Drawing.Point(764, 39);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(32, 33);
            this.linkLabel1.TabIndex = 22;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "<";
            this.linkLabel1.VisitedLinkColor = System.Drawing.Color.Transparent;
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // link
            // 
            this.link.AutoSize = true;
            this.link.BackColor = System.Drawing.Color.Transparent;
            this.link.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.link.LinkColor = System.Drawing.Color.Teal;
            this.link.Location = new System.Drawing.Point(935, 12);
            this.link.Name = "link";
            this.link.Size = new System.Drawing.Size(104, 16);
            this.link.TabIndex = 21;
            this.link.TabStop = true;
            this.link.Text = "Back to Home";
            this.link.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.link_LinkClicked);
            // 
            // Budget
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::LLBB.Properties.Resources.b1;
            this.ClientSize = new System.Drawing.Size(1048, 749);
            this.Controls.Add(this.link);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.panel);
            this.Controls.Add(this.panel3);
            this.Name = "Budget";
            this.Text = "Budget";
            this.Load += new System.EventHandler(this.Budget_Load);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel.ResumeLayout(false);
            this.panel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox Misc;
        private System.Windows.Forms.TextBox date;
        private System.Windows.Forms.TextBox Food;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox Education;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox Medical;
        private System.Windows.Forms.TextBox Internet;
        private System.Windows.Forms.TextBox Bill;
        private System.Windows.Forms.TextBox NetIncm;
        private System.Windows.Forms.TextBox SrcOfIncm;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Editbtn;
        private System.Windows.Forms.Button Delbtn;
        private System.Windows.Forms.Button Addbtn;
        private System.Windows.Forms.Panel panel;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox RemainIncm;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Label Remainlabel;
        private System.Windows.Forms.Label edulabel;
        private System.Windows.Forms.Label datelabel;
        private System.Windows.Forms.Label misclabel;
        private System.Windows.Forms.Label foodlabel;
        private System.Windows.Forms.Label billlabel;
        private System.Windows.Forms.Label medlabel;
        private System.Windows.Forms.Label srclabel;
        private System.Windows.Forms.Label Intlabel;
        private System.Windows.Forms.Label netlabel;
        private System.Windows.Forms.Button Nextbtn;
        private System.Windows.Forms.Button Prevbtn;
        private System.Windows.Forms.RichTextBox nettxt;
        private System.Windows.Forms.RichTextBox billtxt;
        private System.Windows.Forms.RichTextBox srctxt;
        private System.Windows.Forms.RichTextBox foodtxt;
        private System.Windows.Forms.RichTextBox medtxt;
        private System.Windows.Forms.RichTextBox datetxt;
        private System.Windows.Forms.RichTextBox remaintxt;
        private System.Windows.Forms.RichTextBox misctxt;
        private System.Windows.Forms.RichTextBox edutxt;
        private System.Windows.Forms.RichTextBox Inttxt;
        private System.Windows.Forms.Label Textlabel;
        private System.Windows.Forms.LinkLabel link;
    }
}