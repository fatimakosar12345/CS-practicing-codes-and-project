﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LLBB
{
    internal class UserOut
    {
        public static string UserID;
        public static string UserName;
        public static string PassWord;
    }
}
