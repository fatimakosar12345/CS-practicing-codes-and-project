﻿namespace LLBB
{
    partial class Contact_Book
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.name = new System.Windows.Forms.TextBox();
            this.date = new System.Windows.Forms.TextBox();
            this.day = new System.Windows.Forms.TextBox();
            this.address = new System.Windows.Forms.TextBox();
            this.phone = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Editbtn = new System.Windows.Forms.Button();
            this.Delbtn = new System.Windows.Forms.Button();
            this.Addbtn = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.counttxt = new System.Windows.Forms.TextBox();
            this.Textlabel = new System.Windows.Forms.Label();
            this.datetxt = new System.Windows.Forms.RichTextBox();
            this.daytxt = new System.Windows.Forms.RichTextBox();
            this.addresstxt = new System.Windows.Forms.RichTextBox();
            this.phonetxt = new System.Windows.Forms.RichTextBox();
            this.nametxt = new System.Windows.Forms.RichTextBox();
            this.datelabel = new System.Windows.Forms.Label();
            this.daylabel = new System.Windows.Forms.Label();
            this.addresslabel = new System.Windows.Forms.Label();
            this.namelabel = new System.Windows.Forms.Label();
            this.phonelabel = new System.Windows.Forms.Label();
            this.Nextbtn = new System.Windows.Forms.Button();
            this.Prevbtn = new System.Windows.Forms.Button();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Teal;
            this.label2.Location = new System.Drawing.Point(27, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 18);
            this.label2.TabIndex = 8;
            this.label2.Text = "Name";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // name
            // 
            this.name.BackColor = System.Drawing.Color.PowderBlue;
            this.name.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name.ForeColor = System.Drawing.Color.Teal;
            this.name.Location = new System.Drawing.Point(128, 31);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(128, 24);
            this.name.TabIndex = 9;
            this.name.TextChanged += new System.EventHandler(this.name_TextChanged);
            // 
            // date
            // 
            this.date.BackColor = System.Drawing.Color.PowderBlue;
            this.date.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.date.ForeColor = System.Drawing.Color.Teal;
            this.date.Location = new System.Drawing.Point(126, 244);
            this.date.Name = "date";
            this.date.Size = new System.Drawing.Size(130, 24);
            this.date.TabIndex = 11;
            this.date.TextChanged += new System.EventHandler(this.date_TextChanged);
            // 
            // day
            // 
            this.day.BackColor = System.Drawing.Color.PowderBlue;
            this.day.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.day.ForeColor = System.Drawing.Color.Teal;
            this.day.Location = new System.Drawing.Point(126, 189);
            this.day.Name = "day";
            this.day.Size = new System.Drawing.Size(130, 24);
            this.day.TabIndex = 18;
            this.day.TextChanged += new System.EventHandler(this.day_TextChanged);
            // 
            // address
            // 
            this.address.BackColor = System.Drawing.Color.PowderBlue;
            this.address.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.address.ForeColor = System.Drawing.Color.Teal;
            this.address.Location = new System.Drawing.Point(126, 135);
            this.address.Name = "address";
            this.address.Size = new System.Drawing.Size(130, 24);
            this.address.TabIndex = 17;
            this.address.TextChanged += new System.EventHandler(this.Addres_TextChanged);
            // 
            // phone
            // 
            this.phone.BackColor = System.Drawing.Color.PowderBlue;
            this.phone.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phone.ForeColor = System.Drawing.Color.Teal;
            this.phone.Location = new System.Drawing.Point(126, 83);
            this.phone.Name = "phone";
            this.phone.Size = new System.Drawing.Size(130, 24);
            this.phone.TabIndex = 16;
            this.phone.TextChanged += new System.EventHandler(this.phone_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Teal;
            this.label6.Location = new System.Drawing.Point(27, 247);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(39, 18);
            this.label6.TabIndex = 15;
            this.label6.Text = "Date";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Teal;
            this.label5.Location = new System.Drawing.Point(27, 192);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(34, 18);
            this.label5.TabIndex = 14;
            this.label5.Text = "Day";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Teal;
            this.label4.Location = new System.Drawing.Point(27, 138);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 18);
            this.label4.TabIndex = 13;
            this.label4.Text = "Address";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Teal;
            this.label3.Location = new System.Drawing.Point(27, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 18);
            this.label3.TabIndex = 12;
            this.label3.Text = "Phone No.";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.LightSteelBlue;
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.phone);
            this.panel3.Controls.Add(this.date);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.name);
            this.panel3.Controls.Add(this.day);
            this.panel3.Controls.Add(this.address);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Location = new System.Drawing.Point(12, 93);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(282, 300);
            this.panel3.TabIndex = 10;
            // 
            // Editbtn
            // 
            this.Editbtn.BackColor = System.Drawing.Color.PowderBlue;
            this.Editbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Editbtn.ForeColor = System.Drawing.Color.Teal;
            this.Editbtn.Location = new System.Drawing.Point(304, 322);
            this.Editbtn.Name = "Editbtn";
            this.Editbtn.Size = new System.Drawing.Size(138, 46);
            this.Editbtn.TabIndex = 23;
            this.Editbtn.Text = "Edit";
            this.Editbtn.UseVisualStyleBackColor = false;
            this.Editbtn.Click += new System.EventHandler(this.Editbtn_Click);
            // 
            // Delbtn
            // 
            this.Delbtn.BackColor = System.Drawing.Color.PowderBlue;
            this.Delbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Delbtn.ForeColor = System.Drawing.Color.Teal;
            this.Delbtn.Location = new System.Drawing.Point(160, 322);
            this.Delbtn.Name = "Delbtn";
            this.Delbtn.Size = new System.Drawing.Size(138, 46);
            this.Delbtn.TabIndex = 22;
            this.Delbtn.Text = "Delete";
            this.Delbtn.UseVisualStyleBackColor = false;
            this.Delbtn.Click += new System.EventHandler(this.Delbtn_Click);
            // 
            // Addbtn
            // 
            this.Addbtn.BackColor = System.Drawing.Color.PowderBlue;
            this.Addbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addbtn.ForeColor = System.Drawing.Color.Teal;
            this.Addbtn.Location = new System.Drawing.Point(42, 415);
            this.Addbtn.Name = "Addbtn";
            this.Addbtn.Size = new System.Drawing.Size(215, 46);
            this.Addbtn.TabIndex = 21;
            this.Addbtn.Text = "Add";
            this.Addbtn.UseVisualStyleBackColor = false;
            this.Addbtn.Click += new System.EventHandler(this.button2_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Teal;
            this.label7.Location = new System.Drawing.Point(35, 21);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(210, 37);
            this.label7.TabIndex = 24;
            this.label7.Text = "Contact Book";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.panel1.Controls.Add(this.counttxt);
            this.panel1.Controls.Add(this.Textlabel);
            this.panel1.Controls.Add(this.datetxt);
            this.panel1.Controls.Add(this.daytxt);
            this.panel1.Controls.Add(this.addresstxt);
            this.panel1.Controls.Add(this.phonetxt);
            this.panel1.Controls.Add(this.nametxt);
            this.panel1.Controls.Add(this.datelabel);
            this.panel1.Controls.Add(this.daylabel);
            this.panel1.Controls.Add(this.addresslabel);
            this.panel1.Controls.Add(this.namelabel);
            this.panel1.Controls.Add(this.phonelabel);
            this.panel1.Controls.Add(this.Nextbtn);
            this.panel1.Controls.Add(this.Prevbtn);
            this.panel1.Controls.Add(this.Editbtn);
            this.panel1.Controls.Add(this.Delbtn);
            this.panel1.Location = new System.Drawing.Point(313, 70);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(475, 406);
            this.panel1.TabIndex = 19;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // counttxt
            // 
            this.counttxt.Location = new System.Drawing.Point(39, 338);
            this.counttxt.Name = "counttxt";
            this.counttxt.Size = new System.Drawing.Size(100, 20);
            this.counttxt.TabIndex = 38;
            // 
            // Textlabel
            // 
            this.Textlabel.AutoSize = true;
            this.Textlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textlabel.ForeColor = System.Drawing.Color.Teal;
            this.Textlabel.Location = new System.Drawing.Point(139, 168);
            this.Textlabel.Name = "Textlabel";
            this.Textlabel.Size = new System.Drawing.Size(0, 33);
            this.Textlabel.TabIndex = 25;
            // 
            // datetxt
            // 
            this.datetxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.datetxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.datetxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datetxt.ForeColor = System.Drawing.Color.Teal;
            this.datetxt.Location = new System.Drawing.Point(156, 277);
            this.datetxt.Name = "datetxt";
            this.datetxt.Size = new System.Drawing.Size(251, 48);
            this.datetxt.TabIndex = 37;
            this.datetxt.Text = "";
            this.datetxt.TextChanged += new System.EventHandler(this.datetxt_TextChanged);
            // 
            // daytxt
            // 
            this.daytxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.daytxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.daytxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.daytxt.ForeColor = System.Drawing.Color.Teal;
            this.daytxt.Location = new System.Drawing.Point(156, 219);
            this.daytxt.Name = "daytxt";
            this.daytxt.Size = new System.Drawing.Size(251, 48);
            this.daytxt.TabIndex = 36;
            this.daytxt.Text = "";
            // 
            // addresstxt
            // 
            this.addresstxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.addresstxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.addresstxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addresstxt.ForeColor = System.Drawing.Color.Teal;
            this.addresstxt.Location = new System.Drawing.Point(156, 162);
            this.addresstxt.Name = "addresstxt";
            this.addresstxt.Size = new System.Drawing.Size(251, 48);
            this.addresstxt.TabIndex = 35;
            this.addresstxt.Text = "";
            // 
            // phonetxt
            // 
            this.phonetxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.phonetxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.phonetxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phonetxt.ForeColor = System.Drawing.Color.Teal;
            this.phonetxt.Location = new System.Drawing.Point(156, 102);
            this.phonetxt.Name = "phonetxt";
            this.phonetxt.Size = new System.Drawing.Size(251, 48);
            this.phonetxt.TabIndex = 34;
            this.phonetxt.Text = "";
            // 
            // nametxt
            // 
            this.nametxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.nametxt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.nametxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nametxt.ForeColor = System.Drawing.Color.Teal;
            this.nametxt.Location = new System.Drawing.Point(156, 49);
            this.nametxt.Name = "nametxt";
            this.nametxt.Size = new System.Drawing.Size(251, 47);
            this.nametxt.TabIndex = 33;
            this.nametxt.Text = "";
            // 
            // datelabel
            // 
            this.datelabel.AutoSize = true;
            this.datelabel.BackColor = System.Drawing.Color.Transparent;
            this.datelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datelabel.ForeColor = System.Drawing.Color.Teal;
            this.datelabel.Location = new System.Drawing.Point(71, 277);
            this.datelabel.Name = "datelabel";
            this.datelabel.Size = new System.Drawing.Size(39, 18);
            this.datelabel.TabIndex = 32;
            this.datelabel.Text = "Date";
            // 
            // daylabel
            // 
            this.daylabel.AutoSize = true;
            this.daylabel.BackColor = System.Drawing.Color.Transparent;
            this.daylabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.daylabel.ForeColor = System.Drawing.Color.Teal;
            this.daylabel.Location = new System.Drawing.Point(71, 219);
            this.daylabel.Name = "daylabel";
            this.daylabel.Size = new System.Drawing.Size(34, 18);
            this.daylabel.TabIndex = 31;
            this.daylabel.Text = "Day";
            // 
            // addresslabel
            // 
            this.addresslabel.AutoSize = true;
            this.addresslabel.BackColor = System.Drawing.Color.Transparent;
            this.addresslabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addresslabel.ForeColor = System.Drawing.Color.Teal;
            this.addresslabel.Location = new System.Drawing.Point(71, 162);
            this.addresslabel.Name = "addresslabel";
            this.addresslabel.Size = new System.Drawing.Size(62, 18);
            this.addresslabel.TabIndex = 30;
            this.addresslabel.Text = "Address";
            // 
            // namelabel
            // 
            this.namelabel.AutoSize = true;
            this.namelabel.BackColor = System.Drawing.Color.Transparent;
            this.namelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.namelabel.ForeColor = System.Drawing.Color.Teal;
            this.namelabel.Location = new System.Drawing.Point(71, 49);
            this.namelabel.Name = "namelabel";
            this.namelabel.Size = new System.Drawing.Size(48, 18);
            this.namelabel.TabIndex = 29;
            this.namelabel.Text = "Name";
            // 
            // phonelabel
            // 
            this.phonelabel.AutoSize = true;
            this.phonelabel.BackColor = System.Drawing.Color.Transparent;
            this.phonelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phonelabel.ForeColor = System.Drawing.Color.Teal;
            this.phonelabel.Location = new System.Drawing.Point(71, 102);
            this.phonelabel.Name = "phonelabel";
            this.phonelabel.Size = new System.Drawing.Size(79, 18);
            this.phonelabel.TabIndex = 28;
            this.phonelabel.Text = "Phone No.";
            // 
            // Nextbtn
            // 
            this.Nextbtn.BackColor = System.Drawing.Color.PowderBlue;
            this.Nextbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nextbtn.Location = new System.Drawing.Point(418, 161);
            this.Nextbtn.Name = "Nextbtn";
            this.Nextbtn.Size = new System.Drawing.Size(57, 47);
            this.Nextbtn.TabIndex = 2;
            this.Nextbtn.Text = ">";
            this.Nextbtn.UseVisualStyleBackColor = false;
            this.Nextbtn.Click += new System.EventHandler(this.Nextbtn_Click);
            // 
            // Prevbtn
            // 
            this.Prevbtn.BackColor = System.Drawing.Color.PowderBlue;
            this.Prevbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Prevbtn.Location = new System.Drawing.Point(0, 161);
            this.Prevbtn.Name = "Prevbtn";
            this.Prevbtn.Size = new System.Drawing.Size(57, 47);
            this.Prevbtn.TabIndex = 1;
            this.Prevbtn.Text = "<";
            this.Prevbtn.UseVisualStyleBackColor = false;
            this.Prevbtn.Click += new System.EventHandler(this.Prevbtn_Click);
            // 
            // Contact_Book
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::LLBB.Properties.Resources.noice;
            this.ClientSize = new System.Drawing.Size(800, 549);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Addbtn);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Name = "Contact_Book";
            this.Text = "Contact_Book";
            this.Load += new System.EventHandler(this.Contact_Book_Load);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox name;
        private System.Windows.Forms.TextBox date;
        private System.Windows.Forms.TextBox day;
        private System.Windows.Forms.TextBox address;
        private System.Windows.Forms.TextBox phone;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button Editbtn;
        private System.Windows.Forms.Button Delbtn;
        private System.Windows.Forms.Button Addbtn;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Prevbtn;
        private System.Windows.Forms.Button Nextbtn;
        private System.Windows.Forms.RichTextBox datetxt;
        private System.Windows.Forms.RichTextBox daytxt;
        private System.Windows.Forms.RichTextBox addresstxt;
        private System.Windows.Forms.RichTextBox phonetxt;
        private System.Windows.Forms.RichTextBox nametxt;
        private System.Windows.Forms.Label datelabel;
        private System.Windows.Forms.Label daylabel;
        private System.Windows.Forms.Label addresslabel;
        private System.Windows.Forms.Label namelabel;
        private System.Windows.Forms.Label phonelabel;
        private System.Windows.Forms.Label Textlabel;
        private System.Windows.Forms.TextBox counttxt;
    }
}