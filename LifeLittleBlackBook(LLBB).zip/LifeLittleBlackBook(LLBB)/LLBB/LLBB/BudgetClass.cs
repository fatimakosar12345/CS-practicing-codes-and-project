﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LLBBServer
{
    public class BudgetClass
    {

        public static int count;
        public static ArrayList SourceOfIncome = new ArrayList();
        public static ArrayList NetIncome = new ArrayList();
        public static ArrayList BillExp = new ArrayList();
        public static ArrayList MedicalExp = new ArrayList();
        public static ArrayList FoodExp = new ArrayList();
        public static ArrayList InternetExp = new ArrayList();
        public static ArrayList MiscExp = new ArrayList();
        public static ArrayList RIncome = new ArrayList();
        public static ArrayList date = new ArrayList();
        public static ArrayList EduExp = new ArrayList();
       
    }
}