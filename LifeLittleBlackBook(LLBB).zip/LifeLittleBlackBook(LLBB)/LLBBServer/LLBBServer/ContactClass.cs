﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LLBBServer
{
    public class ContactClass
    {
       
        public static int count;
        
        public static List<BlogContact> DataStore = new List<BlogContact>();
    }
}