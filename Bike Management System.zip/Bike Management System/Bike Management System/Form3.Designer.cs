﻿namespace Bike_Management_System
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.showroomToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.purchasedBikesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.soldBikesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.repairBikesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.companyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip3 = new System.Windows.Forms.MenuStrip();
            this.employeesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip4 = new System.Windows.Forms.MenuStrip();
            this.employeesToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ownerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.managerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.staffMembersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip5 = new System.Windows.Forms.MenuStrip();
            this.showroomToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip6 = new System.Windows.Forms.MenuStrip();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.menuStrip2.SuspendLayout();
            this.menuStrip3.SuspendLayout();
            this.menuStrip4.SuspendLayout();
            this.menuStrip5.SuspendLayout();
            this.menuStrip6.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel1.Controls.Add(this.menuStrip1);
            this.panel1.Controls.Add(this.menuStrip2);
            this.panel1.Controls.Add(this.menuStrip3);
            this.panel1.Controls.Add(this.menuStrip4);
            this.panel1.Controls.Add(this.menuStrip5);
            this.panel1.Controls.Add(this.menuStrip6);
            this.panel1.Location = new System.Drawing.Point(29, 18);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(226, 348);
            this.panel1.TabIndex = 0;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.showroomToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 188);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(226, 47);
            this.menuStrip1.TabIndex = 6;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // showroomToolStripMenuItem
            // 
            this.showroomToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.purchasedBikesToolStripMenuItem,
            this.soldBikesToolStripMenuItem,
            this.repairBikesToolStripMenuItem});
            this.showroomToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.showroomToolStripMenuItem.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.showroomToolStripMenuItem.Name = "showroomToolStripMenuItem";
            this.showroomToolStripMenuItem.Padding = new System.Windows.Forms.Padding(61, 7, 81, 7);
            this.showroomToolStripMenuItem.Size = new System.Drawing.Size(201, 43);
            this.showroomToolStripMenuItem.Text = "Bikes";
            this.showroomToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // purchasedBikesToolStripMenuItem
            // 
            this.purchasedBikesToolStripMenuItem.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.purchasedBikesToolStripMenuItem.Name = "purchasedBikesToolStripMenuItem";
            this.purchasedBikesToolStripMenuItem.Size = new System.Drawing.Size(220, 30);
            this.purchasedBikesToolStripMenuItem.Text = "Purchased Bikes";
            // 
            // soldBikesToolStripMenuItem
            // 
            this.soldBikesToolStripMenuItem.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.soldBikesToolStripMenuItem.Name = "soldBikesToolStripMenuItem";
            this.soldBikesToolStripMenuItem.Size = new System.Drawing.Size(220, 30);
            this.soldBikesToolStripMenuItem.Text = "Sold Bikes";
            // 
            // repairBikesToolStripMenuItem
            // 
            this.repairBikesToolStripMenuItem.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.repairBikesToolStripMenuItem.Name = "repairBikesToolStripMenuItem";
            this.repairBikesToolStripMenuItem.Size = new System.Drawing.Size(220, 30);
            this.repairBikesToolStripMenuItem.Text = "Repair Bikes";
            // 
            // menuStrip2
            // 
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.companyToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 141);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(226, 47);
            this.menuStrip2.TabIndex = 7;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // companyToolStripMenuItem
            // 
            this.companyToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.companyToolStripMenuItem.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.companyToolStripMenuItem.Name = "companyToolStripMenuItem";
            this.companyToolStripMenuItem.Padding = new System.Windows.Forms.Padding(38, 7, 60, 7);
            this.companyToolStripMenuItem.Size = new System.Drawing.Size(203, 43);
            this.companyToolStripMenuItem.Text = "Customers";
            // 
            // menuStrip3
            // 
            this.menuStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.employeesToolStripMenuItem});
            this.menuStrip3.Location = new System.Drawing.Point(0, 94);
            this.menuStrip3.Name = "menuStrip3";
            this.menuStrip3.Size = new System.Drawing.Size(226, 47);
            this.menuStrip3.TabIndex = 8;
            this.menuStrip3.Text = "menuStrip3";
            // 
            // employeesToolStripMenuItem
            // 
            this.employeesToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeesToolStripMenuItem.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.employeesToolStripMenuItem.Name = "employeesToolStripMenuItem";
            this.employeesToolStripMenuItem.Padding = new System.Windows.Forms.Padding(42, 7, 66, 7);
            this.employeesToolStripMenuItem.Size = new System.Drawing.Size(204, 43);
            this.employeesToolStripMenuItem.Text = "Company";
            // 
            // menuStrip4
            // 
            this.menuStrip4.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.employeesToolStripMenuItem1});
            this.menuStrip4.Location = new System.Drawing.Point(0, 47);
            this.menuStrip4.Name = "menuStrip4";
            this.menuStrip4.Size = new System.Drawing.Size(226, 47);
            this.menuStrip4.TabIndex = 9;
            this.menuStrip4.Text = "menuStrip4";
            // 
            // employeesToolStripMenuItem1
            // 
            this.employeesToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ownerToolStripMenuItem,
            this.managerToolStripMenuItem,
            this.staffMembersToolStripMenuItem});
            this.employeesToolStripMenuItem1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeesToolStripMenuItem1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.employeesToolStripMenuItem1.Name = "employeesToolStripMenuItem1";
            this.employeesToolStripMenuItem1.Padding = new System.Windows.Forms.Padding(37, 7, 63, 7);
            this.employeesToolStripMenuItem1.Size = new System.Drawing.Size(206, 43);
            this.employeesToolStripMenuItem1.Text = "Employees";
            // 
            // ownerToolStripMenuItem
            // 
            this.ownerToolStripMenuItem.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.ownerToolStripMenuItem.Name = "ownerToolStripMenuItem";
            this.ownerToolStripMenuItem.Size = new System.Drawing.Size(204, 30);
            this.ownerToolStripMenuItem.Text = "Owner";
            this.ownerToolStripMenuItem.Click += new System.EventHandler(this.ownerToolStripMenuItem_Click);
            // 
            // managerToolStripMenuItem
            // 
            this.managerToolStripMenuItem.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.managerToolStripMenuItem.Name = "managerToolStripMenuItem";
            this.managerToolStripMenuItem.Size = new System.Drawing.Size(204, 30);
            this.managerToolStripMenuItem.Text = "Manager";
            // 
            // staffMembersToolStripMenuItem
            // 
            this.staffMembersToolStripMenuItem.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.staffMembersToolStripMenuItem.Name = "staffMembersToolStripMenuItem";
            this.staffMembersToolStripMenuItem.Size = new System.Drawing.Size(204, 30);
            this.staffMembersToolStripMenuItem.Text = "Staff members";
            // 
            // menuStrip5
            // 
            this.menuStrip5.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.showroomToolStripMenuItem1});
            this.menuStrip5.Location = new System.Drawing.Point(0, 0);
            this.menuStrip5.Name = "menuStrip5";
            this.menuStrip5.Size = new System.Drawing.Size(226, 47);
            this.menuStrip5.TabIndex = 10;
            this.menuStrip5.Text = "menuStrip5";
            // 
            // showroomToolStripMenuItem1
            // 
            this.showroomToolStripMenuItem1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.showroomToolStripMenuItem1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.showroomToolStripMenuItem1.Name = "showroomToolStripMenuItem1";
            this.showroomToolStripMenuItem1.Padding = new System.Windows.Forms.Padding(37, 7, 63, 7);
            this.showroomToolStripMenuItem1.Size = new System.Drawing.Size(207, 43);
            this.showroomToolStripMenuItem1.Text = "Showroom";
            this.showroomToolStripMenuItem1.Click += new System.EventHandler(this.showroomToolStripMenuItem1_Click);
            // 
            // menuStrip6
            // 
            this.menuStrip6.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.menuStrip6.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.logoutToolStripMenuItem});
            this.menuStrip6.Location = new System.Drawing.Point(0, 301);
            this.menuStrip6.Name = "menuStrip6";
            this.menuStrip6.Size = new System.Drawing.Size(226, 47);
            this.menuStrip6.TabIndex = 11;
            this.menuStrip6.Text = "menuStrip6";
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoutToolStripMenuItem.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.Padding = new System.Windows.Forms.Padding(54, 7, 72, 7);
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(201, 43);
            this.logoutToolStripMenuItem.Text = "Logout";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.panel1);
            this.panel2.ForeColor = System.Drawing.SystemColors.Window;
            this.panel2.Location = new System.Drawing.Point(26, 24);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(654, 398);
            this.panel2.TabIndex = 12;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Bike_Management_System.Properties.Resources.bak;
            this.pictureBox1.Location = new System.Drawing.Point(290, 18);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(327, 348);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.Window;
            this.panel3.Controls.Add(this.panel2);
            this.panel3.Location = new System.Drawing.Point(99, 38);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(704, 445);
            this.panel3.TabIndex = 13;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.HotTrack;
            this.ClientSize = new System.Drawing.Size(894, 529);
            this.Controls.Add(this.panel3);
            this.ForeColor = System.Drawing.SystemColors.Window;
            this.Name = "Form3";
            this.Text = "Form3";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.menuStrip3.ResumeLayout(false);
            this.menuStrip3.PerformLayout();
            this.menuStrip4.ResumeLayout(false);
            this.menuStrip4.PerformLayout();
            this.menuStrip5.ResumeLayout(false);
            this.menuStrip5.PerformLayout();
            this.menuStrip6.ResumeLayout(false);
            this.menuStrip6.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem showroomToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem purchasedBikesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem soldBikesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem repairBikesToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem companyToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip3;
        private System.Windows.Forms.ToolStripMenuItem employeesToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip4;
        private System.Windows.Forms.ToolStripMenuItem employeesToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ownerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem managerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem staffMembersToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip5;
        private System.Windows.Forms.ToolStripMenuItem showroomToolStripMenuItem1;
        private System.Windows.Forms.MenuStrip menuStrip6;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel3;
    }
}